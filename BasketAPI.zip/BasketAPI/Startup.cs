﻿using Basket.API.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.IO;
using System.Reflection;

namespace Basket.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddTransient<IBasketRepository, BasketRepository>();



            services.AddCors(options =>
            {
                options.AddPolicy("HexPolicy",
                    builder => builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });

            services.AddSingleton<ConnectionMultiplexer>(sp =>
            {
               
                var configuration = new ConfigurationOptions
                {
                    EndPoints = { "localhost" }
                };

                configuration.ResolveDns = true;

                return ConnectionMultiplexer.Connect(configuration);
            });


            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info
                {
                    Title = "Basket API",
                    Version = "v1",
                    Contact = new Contact
                    {
                        Name = "Muthukumar nagaraj",
                        Email = "muthukumarn@hexaware.com",
                        Url = "https://hexblog.azurewebsites.net"
                    },
                    Description = "Blogs written by Muthukumar",
                    TermsOfService = string.Empty,
                    License = new License { Name = "MIT License", Url = "https://hexblog.azurewebsites.net/license" }
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
            });

            //services.AddDistributedRedisCache(option =>
            //{
            //    option.Configuration = "127.0.0.1";
            //    option.InstanceName = "master";
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseStaticFiles();
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "HexaBlog API");
                options.RoutePrefix = string.Empty;
            });

            app.UseMvc();
        }
    }
}
